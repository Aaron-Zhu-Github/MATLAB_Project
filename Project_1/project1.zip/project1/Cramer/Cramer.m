% Cramer method
% Group 33
% @author: HANWEN LIAO, ZHEN REN, JUNREN ZHU

clear;clc

%test cases:
%fileID = fopen('CramerTest1.txt','r');
%fileID = fopen('CramerTest2.txt','r');
%fileID = fopen('CramerTest3.txt','r');
%fileID = fopen('CramerTest4.txt','r');
%fileID = fopen('CramerTest5.txt','r');

%open file
fileID = fopen(file,'r');
scanner = fscanf(fileID,'%f');
fclose(fileID);


%find the matrix size
n = scanner(1);
%check the input is a square matrix or not, or B is empty
if length(scanner) ~= (n * (n+1) +1)
    fprintf('Invalid input');
else
    
    A = [];
    %A = zeros(n,n);
    
    %starting from second index
    a = 2;
    
    %Create an Array A and fill up with the martix A
    A = [];
    for i = 1:n
        for j = 1:n
            A(i,j) = scanner(a);
            a = a + 1;
        end
    end
    
    
    %Create an Array B and fill up with the B->
    B = [];
    %B = zeros(1,n);
    for i = 1:n
        B(i) = scanner(a);
        a = a + 1;
        
    end
    
    %check if there is no solution
    if Determinant(A) == 0
        fprintf('No Solution')
    else
    
    %solution of the determinants
        fprintf("determinant A = "+Determinant(A));
        fprintf('\n');
        for i=1:n
            C=A;
            % i column of the matrix C
            C(:,i)=B;
            fprintf("determinant A"+i+" = "+Determinant(C));
            fprintf('\n');
        end
    
    %solution of the xi
        x = [];
    %x = zeros(1,n)
        d = Determinant(A);
        preA = A;
        if d~= 0
            for i = 1:n
                % i column of the matrix A
                A(:,i) = B;
                % divded by previous det
                x(i)= Determinant(A)/d;
                A = preA;
                fprintf("x"+i+" = "+x(i))
                fprintf('\n');
            end
        end
    end
end
%Algorithm: determinant from Lecture08.pdf
function result = Determinant(A)

% Query only the length of the first dimension of A.
    n = size(A,1); 
    
    sign = 1;
    for i = 1:n-1
        if A(i,i) == 0
            for k = 1:n
                if k > i && A(k,i) ~= 0 %if there exists a row k > i, such that a(k,i)~=0
                    %A(k,:) = A(i,:);
                    
                    temp = A(k,:);
                    A(k,:) = A(i,:);
                    A(i,:) = temp;
    
                    %keep the each determinant + - + - + -...
                    sign = -1 * sign;
                else
                    result = 0;
                end
            end
        else
            %final matrix is an upper triangular matrix
            for j = i+1:n
                A(j,:) = A(j,:) - (A(j,i)/A(i,i))*A(i,:);
            end
        end
    end
    det1 = sign;
    %-1*A(1,1)*A(2,2)...*A(n,n)
    for i = 1:n
        det1 = det1*A(i,i);
    result = det1;
    end
end